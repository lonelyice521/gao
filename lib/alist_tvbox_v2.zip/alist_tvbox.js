"use strict";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0); } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i.return && (_r = _i.return(), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
var key = "xiaoya-tv",
  url = "";
var UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
  cookie = {};
function request(reqUrl, referer, mth, data, hd) {
  var headers = {
      "User-Agent": UA
    };
  var res = req(reqUrl, {method: mth || "get",headers: headers,data: data,
      postType: "post" === mth ? "form" : ""
    });
  return res && res.content ? res.content : "";
}
function init(ext) {
  url = ext;
}
function home(filter) {
    var res = request(url)
    if (url.endsWith("/vod")) {
        res = res.replaceAll("1$/$0", "1$/$1");
    }else{
        res = res.replaceAll("1$/$1", "1$/$0");
    }
  return res;
}
function homeVod() {
  return request(url + "?ids=recommend");
}
function category(tid, pg, filter, extend) {
  pg <= 0 && (pg = 1);
  var api = url + "?t=" + tid + "&pg=" + pg;
  return extend && (tid = Object.entries(extend).map(function () {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : entry,
      _ref2 = _slicedToArray(_ref, 2),
      key = _ref2[0],
      val = _ref2[1];
    return "&" + key + "=" + val;
  }), api = (api += tid) + ("&f=" + encodeURIComponent(JSON.stringify(extend)))), request(api);
}
function detail(id) {
  id = id.split("$");
  return request(url + "?ids=" + id[0] + "$" + id[1]);
}
function play(flag, id, flags) {
  return request(url.replace("/vod1", "/play").replace("/vod", "/play") + "?id=" + id + "&from=open");
}
function search(wd, quick) {
  return request(url + "?wd=" + wd);
}
function __jsEvalReturn() {
  return {
    init: init,
    home: home,
    homeVod: homeVod,
    category: category,
    detail: detail,
    play: play,
    search: search
  };
}
